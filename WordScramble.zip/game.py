import random
import wordlist
import graphics

word_listr = []
ran_words = ""
hint_list = []
next_difficulty = ""

# Randomizes letter placement
def scramble_word(word):
  word_list = list(word)
  word_listr = list(word)
  # Checks to see if the randomized word is not the same as the original word
  while True:
    if word_list == word_listr:
      random.shuffle(word_listr)
    else:
      break
  return word_listr

def answer_response():
  global user_input, ran_words, number_guesses, correct_guess
  if graphics.user_input == ran_words:
    # displays your results
    correct_guess = 1
    graphics.play_again_display()
  else:
    number_guesses = number_guesses + 1
    graphics.start_main_display()
    
def run_hint():
  global number_hints
  # Generates a hint
  word_list = list(ran_words)
  random_index = random.randint(0, len(ran_words) - 1)
  # Checks to make sure the new hint doesn't match any previos hints
  while True:
    if hint_list[random_index] == (word_list[random_index] + " "):
      random_index = random.randint(0, len(ran_words) - 1)
    elif hint_list[random_index] == (word_list[random_index]):
      random_index = random.randint(0, len(ran_words) - 1)
    else:
      break
  if random_index == len(ran_words) - 1:
    hint_list[random_index] = word_list[random_index]
  else:
    hint_list[random_index] = word_list[random_index] + " "
  number_hints += 1
  graphics.start_main_display()

def play_again_button():
    global next_difficulty, difficulty_level
    #asks the user if they want to play again
    if next_difficulty == "y":
      if graphics.difficulty_select == "normal":
        ran_words = random.choice(wordlist.WORDLISTRAN)
        while True:
          if len(ran_words) <= 4 or len(ran_words) >= 8:
            ran_words = random.choice(wordlist.WORDLISTRAN)
          else:
            break
      elif graphics.difficulty_select == "hard":
        ran_words = random.choice(wordlist.WORDLISTRAN)
        while True:
          if len(ran_words) <= 6:
            ran_words = random.choice(wordlist.WORDLISTRAN)
          else:
            break
    elif next_difficulty == "n":
      if graphics.difficulty_select == "hard":
        ran_words = random.choice(wordlist.WORDLISTRAN)
        while True:
          if len(ran_words) <= 4 or len(ran_words) >= 8:
            ran_words = random.choice(wordlist.WORDLISTRAN)
          else:
            break
        graphics.difficulty_select = "normal"
      elif graphics.difficulty_select == "normal":
        ran_words = random.choice(wordlist.WORDLISTRAN)
        while True:
          if len(ran_words) <= 6:
            ran_words = random.choice(wordlist.WORDLISTRAN)
          else:
            break
        graphics.difficulty_select = "hard"
    unscramble_game()

# User will unscramble the word to win, the number of guesses and hints will be tallied
# Then it will displayed at the end.
def unscramble_game():
  global difficulty_select, ran_words, number_guesses, number_hints, correct_guess, scrambled_word
  # User selects the difficulty level of the word they will unscramble
  while True:
    if graphics.difficulty_select == "normal":
      ran_words = random.choice(wordlist.WORDLISTRAN)
      while True:
        if len(ran_words) <= 4 or len(ran_words) >= 6:
          ran_words = random.choice(wordlist.WORDLISTRAN)
        else:
          break
      difficulty_level = "normal"
      break
    elif graphics.difficulty_select == "hard":
      ran_words = random.choice(wordlist.WORDLISTRAN)
      while True:
        if len(ran_words) <= 7:
          ran_words = random.choice(wordlist.WORDLISTRAN)
        else:
          break
      difficulty_level = "hard"
      break
  # sets the Scrambled word
  scrambled_word = scramble_word(ran_words)
  # Keeps track of the number of guesses and hints
  number_guesses = 1
  number_hints = 0
  correct_guesses = 0
  # Displays dashes equal to the length of the word
  hint_list.clear()
  for i in range(len(ran_words) - 1):
    hint_list.append("_ ")
  hint_list.append("_")
  graphics.start_main_display()