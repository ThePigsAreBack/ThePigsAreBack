from tkinter import *
import game
import random
from tkinter import ttk

bg_select = 0
bg_imgs = ["background/purple-sun.png", "background/dark-minimal-mountains.png", "background/summer-is-leaving-nocal.png", "background/space-dark-black-hole-planet.png"]
bg_imgs_acknowledgment = ["Heroscreen Wallpapers on Pintrest", "wallpapersmug.com on Pintrest", "Bootstrap Dashboards on Smashing Mag", "wallpapersmug.com on Pintrest"]
difficulty_select = ""
x = ""
user_input = ""

# Shows the Start Screen
def start_screen():
  global welcome_text, start_button, bg_cycle, bg_select, bg_ack
  welcome_text = Label(text = "Welcome to Word Scrabble")
  welcome_text.pack()
  start_button = Button(text = "START", height = 10, width = 20, command = part_two)
  start_button.pack(pady = 100)
  bg_cycle = Button(text = "Change Background", command = change_bg)
  bg_cycle.place(x = 10, y = 570)
  bg_ack = Label(text = "Art By: " + bg_imgs_acknowledgment[bg_select])
  bg_ack.place(x = 10, y = 610)
  
# Changes the bg imaage
def change_bg():
  global welcome_text, start_button, bg_cycle, bg, bg_select, bg_ack
  welcome_text.forget()
  start_button.destroy()
  bg_cycle.destroy()
  bg_ack.forget()
  bg_select = bg_select + 1
  # Checks to make sure there is a image in bg_imgs and returns to the first bg if not
  if bg_select == len(bg_imgs):
    bg_select = 0
  bg = PhotoImage(file = bg_imgs[bg_select]) 
  bg_png1 = Label(image = bg)
  bg_png1.place(x = 0, y = 0)
  start_screen()

# Shows the Difficulty Selection Screen
def part_two():
  global welcome_text, start_button, bg_cycle, hard_button, normal_button, diff_text_a, diff_text_b, diff_text_c
  welcome_text.forget()
  start_button.destroy()
  bg_cycle.destroy()
  diff_text_a = Label(text = "Choose a Difficulty...")
  diff_text_a.pack()
  diff_text_b = Label(text = "If you choose hard,")
  diff_text_b.pack()
  diff_text_c = Label(text = "you will be given a max of three hints.")
  diff_text_c.pack()
  normal_button = Button(text = "NORMAL", height = 10, width = 20, command = start_run_a)
  normal_button.pack(pady = 20)
  hard_button = Button(text = "HARD", height = 10, width = 20, command = start_run_b, fg = "red")
  hard_button.pack()

# Depending on your secelction, it will change difficulty.
def start_run_a():
  global difficulty_select
  difficulty_select = "normal"
  game.unscramble_game()

def start_run_b():
  global difficulty_select
  difficulty_select = "hard"
  game.unscramble_game()

# The most common screen, shows the main gameplay screen.
def start_main_display():
  global difficulty_select, scrambled_word, user_guess, diff_answer, display_prompt_a, display_scrambled_word, display_hint_list, user_guess, b1, number_hints, give_up_button, hint_button, hard_button, normal_button, diff_text_a, diff_text_b, diff_text_c
  diff_text_a.forget()
  diff_text_b.forget()
  diff_text_c.forget()
  normal_button.destroy()
  hard_button.destroy()
  if difficulty_select == "normal":
    diff_answer = Label(text = "Difficulty selected: Normal")
    diff_answer.pack()
  elif difficulty_select == "hard":
    diff_answer = Label(text = "Difficulty selected: Hard")
    diff_answer.pack()
  display_prompt_a = Label(text = "Enter your guess, or press Hint for a Hint:")
  display_prompt_a.pack()
  display_scrambled_word = Label(text = "".join(game.scrambled_word))
  display_scrambled_word.pack(pady = 20)
  display_hint_list = Label(text = "".join(game.hint_list), font = ('Helvetica bold', 26))
  display_hint_list.pack(pady = 10)
  user_guess = Entry(screen, width= 40)
  user_guess.focus_set()
  user_guess.pack(pady = 40)
  b1 = ttk.Button(screen, text= "ENTER",width= 20, command = users_answer)
  b1.pack(pady=20)
  give_up_button = Button(text = "GIVE UP", command = give_up, fg = "red")
  give_up_button.place(x = 250, y = 400)
  hint_button = Button(text = "HINT", command = hint_button_press, fg = "green")
  hint_button.place(x = 20, y = 400)

# After making a guess, this function will check if the guess is correct.
def users_answer():
  global difficulty_select, user_guess, diff_answer, display_prompt_a, display_scrambled_word, display_hint_list, user_guess, b1, user_input, number_hints, give_up_button, hint_button
  diff_answer.forget()
  display_prompt_a.forget()
  display_scrambled_word.forget()
  display_hint_list.forget()
  user_guess.forget()
  b1.pack_forget()
  give_up_button.destroy()
  hint_button.destroy()
  user_input = "".join(user_guess.get())
  game.answer_response()

# After giving up, this function will show the answer.
def give_up():
  global difficulty_select, user_guess, diff_answer, display_prompt_a, display_scrambled_word, display_hint_list, user_guess, b1, user_input, number_hints, give_up_button, hint_button
  diff_answer.forget()
  display_prompt_a.forget()
  display_scrambled_word.forget()
  display_hint_list.forget()
  user_guess.forget()
  b1.pack_forget()
  give_up_button.destroy()
  hint_button.destroy()
  game.correct_guess = 2
  play_again_display()

# If a hint is requested, this function will show the hint, however will disable the hint button only if certain conditions are met.
def hint_button_press():
  global difficulty_select, user_guess, diff_answer, display_prompt_a, display_scrambled_word, display_hint_list, user_guess, b1, user_input, number_hints, give_up_button, hint_button, ran_words
  diff_answer.forget()
  display_prompt_a.forget()
  display_scrambled_word.forget()
  display_hint_list.forget()
  user_guess.forget()
  b1.pack_forget()
  give_up_button.destroy()
  hint_button.destroy()
  game.run_hint()
  if difficulty_select == "hard" and game.number_hints == 3:
      hint_button.config(state=DISABLED)
  if game.number_hints == len(game.ran_words) - 1:
    hint_button.config(state=DISABLED)

# This is the display if someone wins or gives up, and asks if they want to play again.
def play_again_display():
  global ran_words, number_guesses, number_hints, correct_guess, display_correct_word_a, display_correct_word_b, correct_answer_given, display_number_guesses_a, display_number_guesses_b, display_number_hints_a, display_number_hints_b, play_again_question, play_again_button_y, play_again_button_n
  if game.correct_guess == 2:
    display_correct_word_a = Label(text = "The correct word was:")
    display_correct_word_a.pack()
    display_correct_word_b = Label(text = game.ran_words)
    display_correct_word_b.pack(pady = 10)
  elif game.correct_guess == 1:
    correct_answer_given = Label(text = "Correct!")
    correct_answer_given.pack()
    display_number_guesses_a = Label(text = "Number of Guesses needed: ")
    display_number_guesses_a.pack()
    display_number_guesses_b = Label(text = game.number_guesses)
    display_number_guesses_b.pack(pady = 10)
    display_number_hints_a = Label(text = "Number of Hints needed: ")
    display_number_hints_a.pack()
    display_number_hints_b = Label(text = game.number_hints)
    display_number_hints_b.pack(pady = 10)
  play_again_question = Label(text = "Want to play again?")
  play_again_question.pack()
  play_again_button_y = Button(text = "YES", command = play_again_b, fg = "green")
  play_again_button_n = Button(text = "NO", command = start_menu_question, fg = "red")
  if game.correct_guess == 2:
    play_again_button_y.place(x = 20, y = 100)
    play_again_button_n.place(x = 290, y = 100)
  elif game.correct_guess == 1:
    play_again_button_y.place(x = 20, y = 200)
    play_again_button_n.place(x = 290, y = 200)

# If the user wants to play again, this function will then ask if they want to play again.
def play_again_b():
  global play_same_difficulty, play_again_button_y, play_again_button_n, play_same_difficulty_y, play_same_difficulty_n, correct_guess
  play_again_button_y.config(state=DISABLED)
  play_again_button_n.destroy()
  play_same_difficulty = Label(text = "Play the same Difficulty?")
  play_same_difficulty.pack(pady = 60)
  play_same_difficulty_y = Button(text = "YES", command = start_same_difficulty, fg = "green")
  play_same_difficulty_n = Button(text = "NO", command = change_difficulty, fg = "red")
  if game.correct_guess == 2:
    play_same_difficulty_y.place(x = 20, y = 200)
    play_same_difficulty_n.place(x = 290, y = 200)
  elif game.correct_guess == 1:
    play_same_difficulty_y.place(x = 20, y = 300)
    play_same_difficulty_n.place(x = 290, y = 300)

# If the user wants to play the same difficulty, this function will run the game again.
def start_same_difficulty():
  global next_difficulty
  game.next_difficulty = "y"
  start_again()

# If the user wants to change the difficulty, this function will run the game again.
def change_difficulty():
  global next_difficulty
  game.next_difficulty = "n"
  start_again()

# This will restart the game.
def start_again():
  global play_same_difficulty, play_again_button_y, play_same_difficulty_y, play_same_difficulty_n, display_correct_word_a, display_correct_word_b, correct_answer_given, display_number_guesses_a, display_number_guesses_b, display_number_hints_a, display_number_hints_b, play_again_question
  play_same_difficulty.forget()
  play_again_button_y.destroy()
  play_same_difficulty_y.destroy()
  play_same_difficulty_n.destroy()
  play_again_question.forget()
  if game.correct_guess == 2:
    display_correct_word_a.forget()
    display_correct_word_b.forget()
  elif game.correct_guess == 1:
    correct_answer_given.forget()
    display_number_guesses_a.forget()
    display_number_guesses_b.forget()
    display_number_hints_a.forget()
    display_number_hints_b.forget()
  game.play_again_button()

# If the user does not want to play again, it will then ask if they want to go back to the start menu.
def start_menu_question():
  global correct_guess, play_again_button_y, play_again_button_n, go_to_start_question, start_menu_button_y, start_menu_button_n
  play_again_button_n.config(state=DISABLED)
  play_again_button_y.destroy()
  go_to_start_question = Label(text = "Return to Start menu?")
  go_to_start_question.pack(pady = 60)
  start_menu_button_y = Button(text = "YES", command = start_menu_again, fg = "green")
  start_menu_button_n = Button(text = "NO", fg = "red", command = end_screen)
  if game.correct_guess == 2:
    start_menu_button_y.place(x = 20, y = 200)
    start_menu_button_n.place(x = 290, y = 200)
  elif game.correct_guess == 1:
    start_menu_button_y.place(x = 20, y = 300)
    start_menu_button_n.place(x = 290, y = 300)

# If the user wants to go back to the start menu, this function will run the start menu.
def start_menu_again():
  global correct_guess, display_correct_word_a, display_correct_word_b, correct_answer_given, display_number_guesses_a, display_number_guesses_b, display_number_hints_a, display_number_hints_b, play_again_question, play_again_button_y, play_again_button_n, go_to_start_question, start_menu_button_y, start_menu_button_n
  if game.correct_guess == 2:
    display_correct_word_a.forget()
    display_correct_word_b.forget()
  elif game.correct_guess == 1:
    correct_answer_given.forget()
    display_number_guesses_a.forget()
    display_number_guesses_b.forget()
    display_number_hints_a.forget()
    display_number_hints_b.forget()
  play_again_question.forget()
  play_again_button_n.destroy()
  go_to_start_question.forget()
  start_menu_button_y.destroy()
  start_menu_button_n.destroy()
  start_screen()

# If they didn't want to return to the start menu, this function will end the game.
def end_screen():
  global correct_guess, display_correct_word_a, display_correct_word_b, correct_answer_given, display_number_guesses_a, display_number_guesses_b, display_number_hints_a, display_number_hints_b, play_again_question, play_again_button_y, play_again_button_n, go_to_start_question, start_menu_button_y, start_menu_button_n
  if game.correct_guess == 2:
    display_correct_word_a.forget()
    display_correct_word_b.forget()
  elif game.correct_guess == 1:
    correct_answer_given.forget()
    display_number_guesses_a.forget()
    display_number_guesses_b.forget()
    display_number_hints_a.forget()
    display_number_hints_b.forget()
  play_again_question.forget()
  play_again_button_n.destroy()
  go_to_start_question.forget()
  start_menu_button_y.destroy()
  start_menu_button_n.destroy()
  thanks = Label(text = "Thanks for Playing.", fg = "green")
  thanks.pack(pady = 100)

screen = Tk()
screen.title("Word Scrabble")
screen.geometry("360x640")
bg = PhotoImage(file = bg_imgs[bg_select]) 
bg_png1 = Label(image = bg)
bg_png1.place(x = 0, y = 0)
start_screen()
screen.mainloop()